# Ludo King Android APK

This is an Android wrapper around the original Ludo-style web game. It is configured for modern Android phones and is suitable for the OPPO F29 5G.

## Build an installable APK on GitHub

1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Run **Build Android APK**.
4. Open the completed workflow run.
5. Download the artifact named **LudoKing-OPPO-F29**.
6. Extract it and install `app-debug.apk` on the phone.

The APK is a debug build intended for personal installation/testing.

## Device target

- Android 6.0+ minimum (API 23)
- Target SDK 35
- Java/WebView game, no network permission required
- Portrait orientation
- Designed to work on ARM64 Android phones such as OPPO F29 5G

## Note

This is an original Ludo-style game and is not affiliated with the commercial Ludo King app or its proprietary assets.
