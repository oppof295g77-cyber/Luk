# Ludo King — GitHub Ready

A simple browser-based Ludo game built with plain HTML, CSS and JavaScript.

## Run locally
Open `index.html` in any modern browser.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/root`.
5. Save and open the generated GitHub Pages URL.

## Features
- 2–4 local players
- Dice rolling
- Token movement
- Roll-six-to-enter rule
- Capturing
- Safe squares
- Win detection
- Responsive layout

This is an original lightweight Ludo-style implementation and is not affiliated with or a copy of the commercial Ludo King app.
