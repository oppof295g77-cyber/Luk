const board=document.getElementById("board"),statusEl=document.getElementById("status"),diceEl=document.getElementById("dice");
const colors=["red","green","yellow","blue"];
const starts=[0,13,26,39];
const path=[[6,1],[6,2],[6,3],[6,4],[6,5],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[9,8],[10,8],[11,8],[12,8],[13,8],[14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0],[7,0],[6,0]];
const homes={red:[[1,1],[1,4],[4,1],[4,4]],green:[[1,10],[1,13],[4,10],[4,13]],yellow:[[10,10],[10,13],[13,10],[13,13]],blue:[[10,1],[10,4],[13,1],[13,4]]};
let state,turn=0,roll=null;

function init(){
  state=colors.map(c=>Array(4).fill(-1)); turn=0; roll=null; render();
}
function idx(r,c){return r*15+c}
function render(){
  board.innerHTML="";
  for(let r=0;r<15;r++)for(let c=0;c<15;c++){
    const el=document.createElement("div"); el.className="cell track";
    const inHome=(r<6&&c<6)? "red":(r<6&&c>8)?"green":(r>8&&c>8)?"yellow":(r>8&&c<6)?"blue":null;
    if(inHome){el.className=`cell home ${inHome}`}
    if((r>=6&&r<=8)&&(c>=6&&c<=8)) el.className="cell center";
    const pi=path.findIndex(([a,b])=>a===r&&b===c);
    if(pi>=0){el.className="cell track"; if([0,8,13,21,26,34,39,47].includes(pi))el.classList.add("safe")}
    el.id=`c-${r}-${c}`; board.appendChild(el);
  }
  colors.forEach((col,p)=>{
    state[p].forEach((pos,t)=>{
      const el=document.createElement("div"); el.className=`token ${col}`;
      el.title=`${col} token ${t+1}`;
      const xy=pos<0?homes[col][t]:path[(starts[p]+pos)%52];
      document.getElementById(`c-${xy[0]}-${xy[1]}`).appendChild(el);
      if(roll!==null && p===turn && canMove(p,t,roll)) el.classList.add("selectable");
      el.onclick=()=>{if(p===turn&&roll!==null&&canMove(p,t,roll)) move(p,t,roll)};
    });
    document.getElementById(col+"Count").textContent=`${state[p].filter(x=>x===56).length} / 4`;
  });
  statusEl.textContent=roll===null?`${cap(colors[turn])}'s turn — roll the dice`:`${cap(colors[turn])} rolled ${roll}. ${getMoves(turn,roll).length?"Choose a highlighted token.":"No valid move."}`;
}
function cap(s){return s[0].toUpperCase()+s.slice(1)}
function canMove(p,t,n){let x=state[p][t]; return x===56?false:(x<0?n===6:true)&&x+n<=56}
function getMoves(p,n){return state[p].map((_,t)=>canMove(p,t,n)?t:null).filter(x=>x!==null)}
function move(p,t,n){
  let x=state[p][t]; x=x<0?0:x+n; state[p][t]=x;
  if(x<52){
    const absolute=(starts[p]+x)%52;
    colors.forEach((col,op)=>{
      if(op!==p)state[op].forEach((v,k)=>{if(v>=0&&v<52&&(starts[op]+v)%52===absolute)state[op][k]=-1});
    });
  }
  roll=null;
  if(state[p].every(v=>v===56)){statusEl.textContent=`🎉 ${cap(colors[p])} wins!`; document.getElementById("roll").disabled=true; render(); return}
  if(n!==6)turn=(turn+1)%4;
  render();
}
document.getElementById("roll").onclick=()=>{
  if(roll!==null)return;
  roll=Math.floor(Math.random()*6)+1;
  diceEl.textContent=["⚀","⚁","⚂","⚃","⚄","⚅"][roll-1];
  render();
  if(!getMoves(turn,roll).length){setTimeout(()=>{roll=null;turn=(turn+1)%4;render()},700)}
};
document.getElementById("newGame").onclick=()=>{document.getElementById("roll").disabled=false;init()};
init();